import {cookies} from 'next/headers';
import {db,hash,sameOrigin} from '../../../lib/server';
export async function POST(r:Request){if(!sameOrigin(r))return new Response(null,{status:403});const token=(await cookies()).get('nexo_session')?.value;if(token)await db().prepare('DELETE FROM sessions WHERE token=?').bind(await hash(token)).run();return new Response(null,{status:303,headers:{Location:'/login','Set-Cookie':'nexo_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0'}});}

