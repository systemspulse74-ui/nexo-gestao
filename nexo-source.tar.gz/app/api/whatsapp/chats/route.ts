import { identity, json, sameOrigin } from '../../../lib/server';
import { bridge } from '../../../lib/whatsapp';
export const dynamic = 'force-dynamic';
export async function GET(request: Request) {
  const user = await identity();
  if (!user) return json({error:'Entre na sua conta.'},401);
  const id = new URL(request.url).searchParams.get('id');
  try { return json(await bridge(user.owner, '/chats' + (id ? '?id='+encodeURIComponent(id) : ''))); }
  catch { return json({error:'Não foi possível carregar as conversas. Verifique a conexão.'},503); }
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({error:'Origem inválida.'},403);
  const user = await identity();
  if (!user) return json({error:'Entre na sua conta.'},401);
  try {
    const body = await request.json();
    return json(await bridge(user.owner,'/messages','POST',{id:body.id,phone:body.phone,text:body.text,consent:true}));
  } catch { return json({error:'Não foi possível confirmar o envio. Confira o histórico antes de tentar novamente.'},503); }
}
