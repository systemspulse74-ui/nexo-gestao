import {identity,json,sameOrigin} from '../../lib/server';
import {audit,can} from '../../lib/rbac';
import {getClient} from '../../lib/database';
import {erpReady,normalize,insert,event,quoteStatuses,orderStatuses} from '../../lib/erp';
export const dynamic='force-dynamic';
export async function GET(){const user=await identity();if(!user)return json({error:'Entre na sua conta.'},401);await erpReady();const c=getClient();const readable=new Set<string>();if(await can(user,'quotes.read'))readable.add('quote');if(await can(user,'orders.read'))readable.add('order');if(await can(user,'sales.read'))readable.add('sale');if(await can(user,'receivables.read'))readable.add('receivable');if(!readable.size)return json({error:'Seu perfil não possui acesso a documentos.'},403);const docs=await c.execute({sql:'SELECT * FROM erp_documents WHERE owner=? ORDER BY updated DESC',args:[user.owner]});const visible=docs.rows.filter(r=>readable.has(String(r.kind)));const ids=visible.map(r=>String(r.id));const history=await c.execute({sql:'SELECT * FROM erp_events WHERE owner=? ORDER BY created DESC',args:[user.owner]});const files=await c.execute({sql:'SELECT id,document_id,name,mime FROM erp_files WHERE owner=?',args:[user.owner]});return json({documents:visible.map(r=>({...r,body:JSON.parse(String(r.body))})),events:history.rows.filter(r=>ids.includes(String(r.document_id))),files:files.rows.filter(r=>ids.includes(String(r.document_id)))});}
export async function POST(r:Request){const user=await identity();if(!user)return json({error:'Entre na sua conta.'},401);if(!sameOrigin(r))return json({error:'Origem inválida.'},403);if(Number(r.headers.get('content-length'))>1000000)return json({error:'Documento muito grande.'},413);await erpReady();const tx=await getClient().transaction('write');try{
 const input=await r.json();const owner=user.owner;const actor=user.email;let id=String(input.id||'');let doc:any=null;
 if(id){doc=(await tx.execute({sql:'SELECT * FROM erp_documents WHERE id=? AND owner=?',args:[id,owner]})).rows[0];if(!doc)throw Error('Documento não encontrado.');doc={...doc,body:JSON.parse(String(doc.body))};if(input.version!==doc.version)throw Error('Documento atualizado por outra sessão. Recarregue antes de continuar.');}
 const kind=doc?.kind||input.kind;if(!['quote','order','sale','receivable'].includes(kind))throw Error('Tipo inválido.');const permission=kind==='quote'?'quotes.write':kind==='order'?'orders.write':kind==='sale'?'sales.write':'receivables.write';if(!await can(user,permission))return json({error:'Seu perfil não possui permissão para alterar este documento.'},403);
 if(input.action==='save'){
  if(!['quote','order'].includes(kind))throw Error('Este registro é gerado pela conversão.');
  if(doc&&(kind==='quote'?!['Rascunho','Enviado','Em negociação'].includes(doc.status):['Concluída','Cancelada'].includes(doc.status)))throw Error('O status atual não permite edição.');
  const client=String(input.client_id||'');if(!(await tx.execute({sql:'SELECT id FROM clients WHERE id=? AND owner=?',args:[client,owner]})).rows.length)throw Error('Selecione um cliente válido.');
  if(doc?.source_id&&client!==doc.client_id)throw Error('Mantenha o cliente do orçamento de origem.');
  const body=normalize(input.body,kind);if(doc?.source_id&&kind==='order'&&body.total!==doc.total)throw Error('O valor contratado está vinculado ao orçamento.');
  if(doc){await tx.execute({sql:'UPDATE erp_documents SET client_id=?,body=?,total=?,version=version+1,updated=? WHERE id=? AND owner=?',args:[client,JSON.stringify(body),body.total,new Date().toISOString(),id,owner]});await event(tx,owner,id,actor,'Dados e itens atualizados.');}
  else{id=await insert(tx,owner,kind,client,body,kind==='quote'?'Rascunho':'Aguardando');await event(tx,owner,id,actor,'Documento criado.');}
 }else if(input.action==='duplicate'&&doc&&kind==='quote'){
  id=await insert(tx,owner,'quote',doc.client_id,doc.body,'Rascunho');await event(tx,owner,id,actor,'Duplicado do orçamento nº '+doc.number+' (sem anexos).');
 }else if(input.action==='delete'&&doc){
  if(!((kind==='quote'&&doc.status==='Rascunho')||(kind==='order'&&doc.status==='Aguardando'&&!doc.source_id)))throw Error('Somente rascunhos e OS avulsas aguardando podem ser excluídos.');
  await tx.execute({sql:'DELETE FROM erp_files WHERE document_id=? AND owner=?',args:[id,owner]});await tx.execute({sql:'DELETE FROM erp_documents WHERE id=? AND owner=?',args:[id,owner]});await event(tx,owner,id,actor,'Documento excluído.');
 }else if(input.action==='status'&&doc){
  const status=String(input.status);const list=kind==='quote'?quoteStatuses:kind==='order'?orderStatuses:[];
  if(!list.includes(status)||status==='Convertido'||doc.status==='Convertido'||['Concluída','Cancelada'].includes(doc.status))throw Error('Transição de status não permitida.');
  if(kind==='quote'&&['Aprovado','Rejeitado','Expirado'].includes(doc.status)&&status!=='Rascunho')throw Error('Reabra como rascunho antes de alterar este orçamento.');
  if(status==='Aprovado'&&doc.body.deadline&&doc.body.deadline<new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()))throw Error('Orçamento vencido. Revise a validade antes de aprovar.');
  const body=normalize(doc.body,kind);await tx.execute({sql:'UPDATE erp_documents SET status=?,body=?,version=version+1,updated=? WHERE id=? AND owner=?',args:[status,JSON.stringify(body),new Date().toISOString(),id,owner]});await event(tx,owner,id,actor,doc.status+' → '+status+(status==='Concluída'?' · Resultado calculado com os custos registrados.':''));
 }else if(input.action==='convert'&&doc&&kind==='quote'){
  if(doc.status==='Convertido'){await tx.commit();return json({ok:true,id});}
  if(doc.status!=='Aprovado')throw Error('Aprove o orçamento antes de converter.');
  for(const target of ['sale','order','receivable']){const body=target==='order'?normalize({...doc.body,charged:doc.total/100,costs:[],priority:'Normal',team:'',address:'',description:doc.body.notes||''},'order'):doc.body;const child=await insert(tx,owner,target,doc.client_id,body,target==='order'?'Aguardando':target==='sale'?'Confirmada':'Em aberto',id);await event(tx,owner,child,actor,'Gerado pelo orçamento nº '+doc.number);}
  await tx.execute({sql:'UPDATE erp_documents SET status=?,version=version+1,updated=? WHERE id=? AND owner=?',args:['Convertido',new Date().toISOString(),id,owner]});await event(tx,owner,id,actor,'Aprovado → Convertido: venda, OS e conta a receber criadas.');
 }else throw Error('Operação inválida.');
 await tx.commit();await audit(owner,actor,'erp.'+String(input.action||'save'),'document',id,{kind});return json({ok:true,id});
 }catch(e){await tx.rollback();return json({error:e instanceof Error?e.message:'Não foi possível salvar.'},400);}finally{tx.close();}}
