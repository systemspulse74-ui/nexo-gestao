import {redirect} from 'next/navigation';
import {identity} from '../lib/server';
import AdminPanel from './panel';
export default async function Admin(){const user=await identity();if(!user?.admin)redirect('/');return <AdminPanel/>;}
