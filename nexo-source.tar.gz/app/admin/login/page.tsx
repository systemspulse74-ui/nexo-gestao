import AdminLogin from '../../login/admin-login';
export default function AdminLoginPage(){return <main className="login admin-login-page"><section className="login-form"><div className="login-inner"><a className="brand" href="/">nexo<span className="brand-dot">.</span></a><span className="pill">ÁREA RESTRITA</span><h2>Entrar no painel administrativo</h2><p>Use as credenciais do proprietário da plataforma.</p><AdminLogin/><a className="back-login" href="/login">Voltar para o login</a></div></section></main>}


