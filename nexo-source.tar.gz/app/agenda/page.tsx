import {redirect} from 'next/navigation';
import {identity} from '../lib/server';
import Agenda from './panel';
export const dynamic='force-dynamic';
export default async function Page(){if(!await identity())redirect('/login');return <Agenda/>;}
