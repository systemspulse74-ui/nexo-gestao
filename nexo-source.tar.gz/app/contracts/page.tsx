import {redirect} from 'next/navigation';
import {identity} from '../lib/server';
import ContractsPanel from './panel';
export const dynamic='force-dynamic';
export default async function Contracts(){if(!await identity())redirect('/login');return <ContractsPanel/>;}
