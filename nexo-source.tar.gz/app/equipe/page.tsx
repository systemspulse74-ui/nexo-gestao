import {redirect} from 'next/navigation';
import {identity} from '../lib/server';
import {can} from '../lib/rbac';
import AdminPanel from '../admin/panel';
export default async function Equipe(){const user=await identity();if(!user)redirect('/login');if(!await can(user,'access.manage'))redirect('/');return <AdminPanel/>;}
