import {db,identity,json} from './server';

export const roles={
  PROPRIETÁRIO:['*'],
  ADMINISTRADOR:['clients.read','clients.write','finance.read','finance.write','reports.read','sales.read','sales.write','quotes.read','quotes.write','orders.read','orders.write','tasks.read','tasks.write','access.manage','audit.read'],
  FINANCEIRO:['finance.read','finance.write','reports.read','receivables.read','receivables.write'],
  VENDEDOR:['clients.read','clients.write','crm.read','crm.write','sales.read','sales.write','quotes.read','quotes.write'],
  PRODUÇÃO:['orders.read','orders.write','tasks.read','tasks.write','stock.read','stock.write']
} as const;
export type Permission=string;

export async function roleFor(email:string,owner:boolean){
  if(owner)return 'PROPRIETÁRIO';
  const row=await db().prepare('SELECT role FROM access_list WHERE email=?').bind(email).first();
  return String(row?.role||'VENDEDOR').toUpperCase();
}
export async function permissionsFor(role:string){
  const base=(roles as Record<string,readonly string[]>)[role];
  if(base)return [...base];
  const row=await db().prepare('SELECT permissions FROM rbac_roles WHERE id=?').bind(role).first();
  try{return Array.isArray(JSON.parse(String(row?.permissions||'[]')))?JSON.parse(String(row?.permissions||'[]')):[];}catch{return []}
}
export async function can(user:Awaited<ReturnType<typeof identity>>,permission:Permission){
  if(!user)return false;
  const permissions=await permissionsFor(user.role);
  return permissions.includes('*')||permissions.includes(permission);
}
export async function requirePermission(permission:Permission){
  const user=await identity();
  if(!user)return {user:null,response:json({error:'Entre na sua conta.'},401)};
  if(!await can(user,permission))return {user:null,response:json({error:'Seu perfil não possui permissão para esta ação.'},403)};
  return {user,response:null};
}
export async function audit(owner:string,actor:string,action:string,entity:string,entityId:string|null,details:unknown={}){
  await db().prepare('INSERT INTO audit_logs VALUES(?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),owner,actor,action.slice(0,100),entity.slice(0,80),entityId,JSON.stringify(details).slice(0,4000),new Date().toISOString()).run();
}
