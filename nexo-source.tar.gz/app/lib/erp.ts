import {getClient,database} from './database';
import type {Transaction} from '@libsql/client';
export const quoteStatuses=['Rascunho','Enviado','Em negociação','Aprovado','Rejeitado','Expirado','Convertido'];
export const orderStatuses=['Aguardando','Aprovada','Em produção','Em andamento','Aguardando material','Pronta','Agendada para instalação','Concluída','Cancelada'];
let ready:Promise<unknown>|undefined;
export async function erpReady(){await database().prepare('SELECT 1').first();if(!ready)ready=getClient().batch([
`CREATE TABLE IF NOT EXISTS erp_migrations(version INTEGER PRIMARY KEY, applied TEXT NOT NULL)`,
`CREATE TABLE IF NOT EXISTS erp_documents(id TEXT PRIMARY KEY,owner TEXT NOT NULL,kind TEXT NOT NULL,number INTEGER NOT NULL,client_id TEXT NOT NULL,source_id TEXT,status TEXT NOT NULL,body TEXT NOT NULL,total INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,created TEXT NOT NULL,updated TEXT NOT NULL,UNIQUE(owner,kind,number),UNIQUE(owner,kind,source_id))`,
`CREATE INDEX IF NOT EXISTS erp_owner ON erp_documents(owner,kind)`,
`CREATE TABLE IF NOT EXISTS erp_events(id TEXT PRIMARY KEY,owner TEXT NOT NULL,document_id TEXT NOT NULL,actor TEXT NOT NULL,description TEXT NOT NULL,created TEXT NOT NULL)`,
`CREATE TABLE IF NOT EXISTS erp_files(id TEXT PRIMARY KEY,owner TEXT NOT NULL,document_id TEXT NOT NULL,name TEXT NOT NULL,mime TEXT NOT NULL,content BLOB NOT NULL,created TEXT NOT NULL)`,
`CREATE TABLE IF NOT EXISTS calendar_events(id TEXT PRIMARY KEY,owner TEXT NOT NULL,type TEXT NOT NULL,title TEXT NOT NULL,client_id TEXT,order_id TEXT,responsible TEXT NOT NULL,date TEXT NOT NULL,time TEXT,deadline TEXT,priority TEXT NOT NULL,status TEXT NOT NULL,description TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL)`,
`CREATE INDEX IF NOT EXISTS calendar_owner_date ON calendar_events(owner,date)`,
`CREATE TRIGGER IF NOT EXISTS protect_erp_clients BEFORE DELETE ON clients WHEN EXISTS(SELECT 1 FROM erp_documents WHERE client_id=OLD.id AND owner=OLD.owner) BEGIN SELECT RAISE(ABORT,'Cliente possui documentos vinculados'); END`,
`INSERT OR IGNORE INTO erp_migrations VALUES(1,datetime('now'))`,
`INSERT OR IGNORE INTO erp_migrations VALUES(2,datetime('now'))`
],'write').catch(e=>{ready=undefined;throw e});await ready;}
export function checkDate(v:string){if(!/^\d{4}-\d{2}-\d{2}$/.test(v)||new Date(v+'T12:00:00Z').toISOString().slice(0,10)!==v)throw Error('Data inválida.');return v;}
export function amount(v:unknown){const n=Number(v);if(!Number.isFinite(n)||n<0||n>1e8)throw Error('Valor inválido.');return Math.round(n*100);}
export function normalize(b:any,kind:string){
 const body={...b};checkDate(body.date);if(body.deadline)checkDate(body.deadline);
 if(!String(body.title||'').trim())throw Error('Informe o título.');if(String(body.title).length>200)throw Error('Título muito longo.');
 if(!Array.isArray(body.items)||body.items.length>200)throw Error('Itens inválidos.');
 let subtotal=0;body.items=body.items.map((i:any)=>{const quantity=Number(i.quantity);if(!i.name?.trim()||!Number.isFinite(quantity)||quantity<=0||quantity>1e6)throw Error('Confira descrição e quantidade dos itens.');const cents=amount(i.price);const total=Math.round(quantity*cents);subtotal+=total;return {name:String(i.name).slice(0,200),kind:i.kind==='Serviço'?'Serviço':'Produto',unit:String(i.unit||'un').slice(0,20),quantity,price:cents/100,total};});
 if(kind==='quote'&&!body.items.length)throw Error('Adicione pelo menos um item.');
 const discount=amount(body.discount||0),extra=amount(body.extra||0),tax=amount(body.tax||0);const total=kind==='quote'?subtotal-discount+extra+tax:amount(body.charged||0);if(total<0||!Number.isSafeInteger(total)||total>1e12)throw Error('Total inválido.');
 const costs=Array.isArray(body.costs)?body.costs:[];if(costs.length>200)throw Error('Limite de custos excedido.');let costTotal=0;
 body.costs=costs.map((c:any)=>{const quantity=Number(c.quantity);if(!c.name?.trim()||!Number.isFinite(quantity)||quantity<=0||quantity>1e6)throw Error('Confira os custos.');const unitCost=amount(c.price);const total=Math.round(quantity*unitCost);costTotal+=total;return {name:String(c.name).slice(0,200),category:String(c.category||'Outros'),unit:String(c.unit||'un'),quantity,price:unitCost/100,total};});
 if(!Number.isSafeInteger(costTotal)||costTotal>1e12)throw Error('Custo total inválido.');
 return {...body,subtotal,total,costTotal,profit:total-costTotal,margin:total?((total-costTotal)/total)*100:0};
}
export async function event(tx:Transaction,owner:string,id:string,actor:string,description:string){await tx.execute({sql:'INSERT INTO erp_events VALUES(?,?,?,?,?,?)',args:[crypto.randomUUID(),owner,id,actor,description,new Date().toISOString()]});}
export async function insert(tx:Transaction,owner:string,kind:string,client:string,body:any,status:string,source:string|null=null){const id=crypto.randomUUID();const now=new Date().toISOString();await tx.execute({sql:`INSERT INTO erp_documents(id,owner,kind,number,client_id,source_id,status,body,total,created,updated) SELECT ?,?,?,COALESCE(MAX(number),0)+1,?,?,?,?,?,?,? FROM erp_documents WHERE owner=? AND kind=?`,args:[id,owner,kind,client,source,status,JSON.stringify(body),body.total,now,now,owner,kind]});return id;}
