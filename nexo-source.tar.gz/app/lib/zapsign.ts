type Signer={name:string,email?:string,phone?:string,auth_mode?:'assinaturaTela'|'tokenEmail'|'assinaturaTela-tokenEmail'|'tokenSms'|'tokenWhatsapp'|'certificadoDigital'};
const endpoint='https://api.zapsign.com.br/api/v1/docs/';
export function zapSignConfigured(){return !!process.env.ZAPSIGN_API_TOKEN;}
export async function createZapSignDocument(input:{name:string,markdown:string,signers:Signer[],externalId:string,deadline?:string,brandName?:string}){
 const token=process.env.ZAPSIGN_API_TOKEN;if(!token)throw Error('Provedor de assinatura não configurado.');
 if(!input.signers.length)throw Error('Informe ao menos um signatário.');
 const signers=input.signers.map(s=>({name:s.name.slice(0,120),email:s.email?.slice(0,200)||'',phone_country:s.phone?'55':'',phone_number:s.phone?.replace(/\D/g,'')||'',auth_mode:s.auth_mode||'assinaturaTela-tokenEmail'}));
 const response=await fetch(endpoint,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({name:input.name.slice(0,255),markdown_text:input.markdown,signers,external_id:input.externalId,lang:'pt-br',date_limit_to_sign:input.deadline||undefined,folder_path:'/nexo/contratos/',signature_order_active:false,allow_refuse_signature:true,brand_name:input.brandName?.slice(0,100)||'Nexo'}),signal:AbortSignal.timeout(15000)});
 const data=await response.json().catch(()=>({}));if(!response.ok)throw Error(String(data?.detail||data?.message||'A ZapSign recusou a criação do documento.').slice(0,500));
 return {token:String(data.token||''),status:String(data.status||'pending'),signers:Array.isArray(data.signers)?data.signers.map((s:any)=>({token:String(s.token||''),name:String(s.name||''),url:s.token?'https://app.zapsign.com.br/verificar/'+s.token:''})):[],createdAt:data.created_at||new Date().toISOString()};
}
export async function getZapSignDocument(token:string){const api=process.env.ZAPSIGN_API_TOKEN;if(!api)throw Error('Provedor de assinatura não configurado.');const response=await fetch(endpoint+encodeURIComponent(token)+'/',{headers:{Authorization:'Bearer '+api},signal:AbortSignal.timeout(15000)});const data=await response.json().catch(()=>({}));if(!response.ok)throw Error('Não foi possível consultar o documento na ZapSign.');return data;}
