import {cookies} from 'next/headers';
import {database,databaseConfigured} from './database';
export const config=()=>process.env as Record<string,string>;
export const db=database;
export const ADMIN_EMAIL='systemspulse74@gmail.com';
export const ADMIN_PASSWORD='Pulse123!';
export function authConfigured(){return databaseConfigured()&&!!config().APP_URL;}
export async function hash(v:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v)))).map(v=>v.toString(16).padStart(2,'0')).join('')}
export async function identity(){if(!authConfigured())return null;const token=(await cookies()).get('nexo_session')?.value;if(!token)return null;const row=await db().prepare('SELECT * FROM sessions WHERE token=? AND expires>?').bind(await hash(token),Date.now()).first();if(!row)return null;const email=String(row.email).toLowerCase();let role='VENDEDOR',permissions:string[]|null=null;if(email!==ADMIN_EMAIL){const allowed=await db().prepare('SELECT * FROM access_list WHERE email=? AND status=? AND (expires IS NULL OR expires>?)').bind(email,'active',Date.now()).first();if(!allowed)return null;role=String(allowed.role||'VENDEDOR').toUpperCase();try{const parsed=JSON.parse(String(allowed.permissions||'null'));permissions=Array.isArray(parsed)?parsed.filter(v=>typeof v==='string'):null}catch{permissions=null}}else role='PROPRIETÁRIO';return {owner:String(row.owner),email,name:String(row.name),provider:String(row.provider||'Google'),admin:email===ADMIN_EMAIL,role,permissions};}
export function json(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store'}})}
export function sameOrigin(r:Request){return !!config().APP_URL&&r.headers.get('origin')===new URL(config().APP_URL).origin;}
export const defaults={business:'Meu negócio',message:'Olá, {{nome}}! Seja bem-vindo(a) à {{empresa}}. É um prazer ter você por aqui! Como podemos ajudar?',template:'',language:'pt_BR',automated:0};
