import type { Metadata } from "next";
import "./globals.css";
import SidebarContractsLink from './sidebar-contracts-link';

export const metadata: Metadata = {
  title: "Nexo · Seu negócio, em equilíbrio",
  description: "Clientes, finanças e WhatsApp em um só lugar.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}<SidebarContractsLink/></body>
    </html>
  );
}
