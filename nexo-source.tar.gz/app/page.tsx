import Dashboard from './dashboard';
import { identity } from './lib/server';
import { can } from './lib/rbac';
import { redirect } from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Home(){const user=await identity();if(!user)redirect('/login');const manage=await can(user,'access.manage');return <><Dashboard/><a className="contracts-access" href="/contracts">Contratos</a>{manage&&<a className="team-access" href="/equipe">Equipe e permissões</a>}</>}
